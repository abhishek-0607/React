import { useState } from "react";
export const Login = () => {
  return (
    <>
      <input type="text" />
      <input type="password" />
      <button onClick={() => {}}>Login</button>
    </>
  );
};
