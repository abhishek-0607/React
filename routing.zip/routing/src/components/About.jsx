export const About = () => {
  return <h3>About Page</h3>;
};
